package ficha_3_ex3;

public class Ficha_3_ex3 {

    public static void main(String[] args) {
        int valores[] = {1, 2, 3, 4, 5 ,6 ,7 ,8};
        
        try{
            boolean existe = verifcaExistenciaValor(valores, 5);
            System.out.println("Valor existe!");
        } catch(ValorNaoExisteException ex){
            System.out.println("Valor não existe");
        }
        
    }
    
    public static boolean verifcaExistenciaValor(int array[], int valor) throws ValorNaoExisteException{
        for(int temp : array){
            if(temp == valor)
                    return true;
        }
        throw new ValorNaoExisteException();
    }
    
}
