
package ficha_3_ex1;

public class Ficha_3_ex1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Publicacao p1 = new Publicacao();
        p1.introduzirDados("Publicação 1");
        
        Publicacao p2 = new Publicacao();
        p2.introduzirDados("Publicação 2");
        
        System.out.println("Informação Publicações: ");
        p1.mostraInformacao();
        p2.mostraInformacao();
        
        System.out.println("Quantidade de Publicações pedidas pelo objeto px: ");
        // como quantidade de publicações é variável de classe, o valor é igual e acessível por todas os objetos do tipo Publicacao
        System.out.println("p1 - " + p1.obterQuantidadePublicacoes());
        System.out.println("p2 - " + p2.obterQuantidadePublicacoes());
    
        
        Livro l1 = new Livro();
        l1.introduzirDados("Livro 1", "Autor do livro 1");
    
        l1.mostraInformacao();
        
        Revista r1 = new Revista();
        r1.introduirDados("Revista 1", 10);
        
        r1.mostraInformacao();
    }
    
}
