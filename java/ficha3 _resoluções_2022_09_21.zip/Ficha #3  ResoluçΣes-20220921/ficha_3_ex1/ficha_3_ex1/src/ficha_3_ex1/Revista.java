
package ficha_3_ex1;

/**
 *
 * @author Vasco Alves
 */
public class Revista extends Publicacao {
    private int numeroRevista = 0;
    
    public Revista(){
        super();
    }
    
    @Override
    public void mostraInformacao(){
        System.out.println(this.getNome() + " | " + this.numeroRevista);
    }
    
    public void introduirDados(String nome, int numeroRevista){
        this.setNome(nome);
        this.numeroRevista = numeroRevista;
    }
}
