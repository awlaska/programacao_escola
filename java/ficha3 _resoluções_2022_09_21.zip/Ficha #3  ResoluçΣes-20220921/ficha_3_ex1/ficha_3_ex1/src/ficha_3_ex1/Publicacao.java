package ficha_3_ex1;


public class Publicacao {
    private String nome = "";
    private static int quantidadePublicacoes = 0;
    private int numeroPublicacao = 0;
    
    
    public Publicacao(){
        this.numeroPublicacao = quantidadePublicacoes;
        quantidadePublicacoes++;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public int getNumeroPublicacao(){
        return this.numeroPublicacao;
    }
    
    public void setNumeroPublicacao(int numero){
        this.numeroPublicacao = numero;
    }
    
    public void mostraInformacao(){
        System.out.println(this.nome + " | #" + this.numeroPublicacao);
    }
    
    public void introduzirDados(String nome){
        this.nome = nome;
    }
    
    public int obterNumeroPublicacao(){
        return this.numeroPublicacao;
    }
    
    public int obterQuantidadePublicacoes(){
        return quantidadePublicacoes;
    }
}

