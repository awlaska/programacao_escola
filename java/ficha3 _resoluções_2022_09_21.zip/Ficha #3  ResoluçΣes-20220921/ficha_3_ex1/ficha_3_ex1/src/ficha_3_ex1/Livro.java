
package ficha_3_ex1;


public class Livro extends Publicacao {
    private String autor = "";
    
    public Livro(){
        super();
    }
    
    @Override
    public void mostraInformacao(){
        System.out.println(this.getNome() + " - Autor: " + this.autor + " | #" + this.getNumeroPublicacao());
    }
    
    public void introduzirDados(String nome, String autor){
        this.setNome(nome);
        this.autor = autor;
    }
    
}
