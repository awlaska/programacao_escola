/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex_5;


public class Aquecedor extends Ventoinha{
    
    private boolean resistenciaLigada = false;
    private Velocidade potenciaResistencia = Velocidade.BAIXA;
    
    public Aquecedor(){}

    public Velocidade getPotenciaResistencia() {
        return potenciaResistencia;
    }

    public void setPotenciaResistencia(Velocidade potenciaResistencia) {
        this.potenciaResistencia = potenciaResistencia;
    }

    public boolean resistenciaLigada() {
        return resistenciaLigada;
    }
    
    public void ligarAquecimento(){
        this.resistenciaLigada = true;
        this.potenciaResistencia = Velocidade.BAIXA;
    }
    
    public void desligarAquecimento(){
        this.resistenciaLigada = false;
    }
    
    @Override
    public String toString(){
        String string = "";
        if(this.resistenciaLigada){
            switch(this.potenciaResistencia){
                case BAIXA:
                    string = "Aquecimento Ligada! | Potência: Baixa | " + super.toString();
                    break;
                case MEDIA:
                    string = "Aquecimento Ligada! | Potência: Média | " + super.toString();
                    break;
                case ALTA:
                    string = "Aquecimento Ligada! | Potência: Alta | " + super.toString();
                    break;
            }
        } else {
            string = "Aquecimento Desligado! | " + super.toString();
        }
        
        return string;
    }
    
}
