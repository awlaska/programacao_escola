/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex_5;


public class Climatizador extends Aquecedor {
    
    private boolean refrigeracaoLigada = false;
    private Velocidade potenciaRefrigerador = Velocidade.BAIXA;
    
    public Climatizador(){}

    public boolean refrigeracaoLigada() {
        return refrigeracaoLigada;
    }

    public Velocidade getPotenciaRefrigerador() {
        return potenciaRefrigerador;
    }

    public void setPotenciaRefrigerador(Velocidade potenciaRefrigerador) {
        this.potenciaRefrigerador = potenciaRefrigerador;
    }
    
    public void ligarRefrigeracao(){
        this.desligarAquecimento();
        this.refrigeracaoLigada = true;
        this.potenciaRefrigerador = Velocidade.BAIXA;
    }
    
    public void desligarRefrigeracao(){
        this.refrigeracaoLigada = false;
    }
    
    @Override
    public void ligarAquecimento(){
        this.refrigeracaoLigada = false;
        super.ligarAquecimento();
    }
    
    @Override
    public String toString(){
        String string = "";
        
        if(refrigeracaoLigada){
            switch(this.potenciaRefrigerador){
                case BAIXA:
                    string = "Refrigeração Ligada! | Potência de Refrigeração: Baixa";
                    break;
                case MEDIA:
                    string = "Refrigeração Ligada! | Potência de Refrigeração: Média";
                    break;
                case ALTA:
                    string = "Refrigeração Ligada! | Potência de Refrigeração: Alta";
                    break;
            }
        } else {
            string = "Refrigeração Desligada!";
        }
        
        string = string.concat(" | " +  super.toString());
        
        return string;
    }    
    
}
