/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex_5;

public class Ventoinha {
    
    private boolean ventoinhaLigada = false;
    private Velocidade velocidadeVentoinha = Velocidade.BAIXA;
    
    public Ventoinha(){}

    public Velocidade getVelocidadeVentoinha() {
        return velocidadeVentoinha;
    }

    public void setVelocidadeVentoinha(Velocidade velocidadeVentoinha) {
        this.velocidadeVentoinha = velocidadeVentoinha;
    }

    public boolean ventoinhaLigada() {
        return ventoinhaLigada;
    }
    
    public void ligar(){
        this.ventoinhaLigada = true;
        this.velocidadeVentoinha = Velocidade.BAIXA;
    }
    
    public void desligar(){
        this.ventoinhaLigada = false;
    }
    
    @Override
    public String toString(){
        String string = "";
        if(this.ventoinhaLigada){
            switch(this.velocidadeVentoinha){
                case BAIXA:
                    string = "Ventoinha Ligada! Velocidade: Baixa";
                    break;
                case MEDIA:
                    string = "Ventoinha Ligada! Velocidade: Média";
                    break;
                case ALTA:
                    string = "Ventoinha Ligada! Velocidade: Alta";
                    break;
            }
        } else {
            string = "Ventoinha Desligada!";
        }
        
        return string;
    }
    
    
}
