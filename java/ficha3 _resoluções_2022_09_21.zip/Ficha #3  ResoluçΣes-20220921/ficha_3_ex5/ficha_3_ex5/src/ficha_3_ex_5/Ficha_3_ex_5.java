/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex_5;


public class Ficha_3_ex_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Ventoinha v1 = new Ventoinha();
        v1.ligar();
        v1.setVelocidadeVentoinha(Velocidade.ALTA);
        System.out.println("Informação da Ventoinha: " + v1);
        
        Aquecedor a1 = new Aquecedor();
        a1.ligarAquecimento();
        a1.ligar();
        a1.setPotenciaResistencia(Velocidade.MEDIA);
        System.out.println("Informação do Aquecedor: " + a1);
        
        Climatizador c1 = new Climatizador();
        c1.ligarAquecimento();
        c1.setPotenciaResistencia(Velocidade.ALTA);
        System.out.println("Informação Atual Climatizador: " + c1);
        
        c1.ligarRefrigeracao();
        System.out.println("Informação Atual Climatizador: " + c1);
        
    }
    
}
