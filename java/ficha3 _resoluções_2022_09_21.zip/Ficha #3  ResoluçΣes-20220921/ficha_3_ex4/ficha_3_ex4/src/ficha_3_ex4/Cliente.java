/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex4;

public class Cliente {
    private String nome = "";
    private String cidade = "";
    private String NIF = "";
    
    public Cliente(){}
    
    public String getNome(){
        return this.nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getCidade(){
        return this.cidade;
    }
    
    public void setCidade(String cidade){
        this.cidade = cidade;
    }
    
    public String getNIF(){
        return this.NIF;
    }
    
    public void setNIF(String nif){
        this.NIF = nif;
    }
    
    @Override
    public String toString(){
        return "Nome: " + this.nome + " | Cidade: " + this.cidade + " | NIF: " + this.NIF;
    }
}
