/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex4;

public class ListaClientes {
    private Cliente[] clientes = null;
    
    public ListaClientes(){
        this.clientes = new Cliente[50];
    }
    
    public Cliente[] getClientes(){
        return this.clientes;
    }
    
    public void setClientes(Cliente[] clientes){
        this.clientes = clientes;
    }
    
    public boolean adicionarCliente(Cliente cliente) throws NIFRepetidoException{
        for(int x = 0; x < this.clientes.length; x++){
            if(this.clientes[x] == null){
                this.clientes[x] = cliente;
                return true;
            } else {
                if(this.clientes[x].getNIF().equals(cliente.getNIF())){
                    throw new NIFRepetidoException();
                }
            }
        }
        return false;
    }
    
    public Cliente procurarClientePorNIF(String nif) throws ClienteNaoExisteException{
        for(Cliente cTemp : this.clientes){
            if(cTemp != null)
                if(cTemp.getNIF().equals(nif)){
                    return cTemp;
                }
        }
        
        throw new ClienteNaoExisteException();
    }
    
}
 
