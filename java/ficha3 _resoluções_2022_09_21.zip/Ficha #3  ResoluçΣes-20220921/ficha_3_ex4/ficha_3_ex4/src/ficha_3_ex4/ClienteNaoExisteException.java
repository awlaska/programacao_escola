/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha_3_ex4;


public class ClienteNaoExisteException extends Exception{
    
    public ClienteNaoExisteException(){
        super();
    }
    
}
