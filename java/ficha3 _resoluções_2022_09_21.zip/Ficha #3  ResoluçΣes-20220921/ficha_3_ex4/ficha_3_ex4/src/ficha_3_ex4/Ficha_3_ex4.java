
package ficha_3_ex4;

import java.util.logging.Level;
import java.util.logging.Logger;


public class Ficha_3_ex4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c1 = new Cliente();
        c1.setNome("Cliente 1");
        c1.setCidade("Cidade 1");
        c1.setNIF("123456789");
        
        Cliente c2 = new Cliente();
        c2.setNome("Cliente 2");
        c2.setCidade("Cidade 2");
        c2.setNIF("123456999");
        
        System.out.println(c1.toString());
        
        ListaClientes lista = new ListaClientes();
        
        try {
            lista.adicionarCliente(c1);
            System.out.println("Adicionado!");
        } catch (NIFRepetidoException ex) {
            System.out.println("NIF Repetido");
        }
        
        try {
            lista.adicionarCliente(c2);
            System.out.println("Adicionado!");
        } catch (NIFRepetidoException ex) {
            System.out.println("NIF Repetido");
        }
        
        try {
            lista.adicionarCliente(c1);
            System.out.println("Adicionado!");
        } catch (NIFRepetidoException ex) {
            System.out.println("NIF Repetido");
        }
        
        try{
            System.out.println(lista.procurarClientePorNIF("123456789"));
        } catch(ClienteNaoExisteException ex){
            System.out.println("Não existe cliente com esse NIF");
        }
        
        try{
            System.out.println(lista.procurarClientePorNIF("123"));
        } catch(ClienteNaoExisteException ex){
            System.out.println("Não existe cliente com esse NIF");
        }
        
    }
    
}
