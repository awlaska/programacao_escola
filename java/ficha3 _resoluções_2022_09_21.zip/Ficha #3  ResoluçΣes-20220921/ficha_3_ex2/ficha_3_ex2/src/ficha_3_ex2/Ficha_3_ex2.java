package ficha_3_ex2;

import java.util.NoSuchElementException;

public class Ficha_3_ex2 {

    public static void main(String[] args) {
        int valores[] = {1, 2, 3, 4, 5 ,6 ,7 ,8};
        
        try{
            boolean existe = verifcaExistenciaValor(valores, 10);
            System.out.println("Valor existe!");
        } catch(NoSuchElementException ex){
            System.out.println("Valor não existe");
        }
        
    }
    
    public static boolean verifcaExistenciaValor(int array[], int valor) throws NoSuchElementException{
        for(int temp : array){
            if(temp == valor)
                    return true;
        }
        throw new NoSuchElementException();
    }
    
}
